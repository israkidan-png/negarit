# ነጋሪት · Negarit — Complete Platform

## Files

| File | Purpose |
|------|---------|
| `index.html` | Main landing page — hero, search, library preview, features, founder, waitlist |
| `search.html` | Dedicated full-search page with category pills and sorting |
| `law.html` | Individual law detail page (load any law with `?id=labour-1156-2019`) |
| `style.css` | Shared stylesheet for all three pages |
| `laws-data.js` | Law database (8 laws), i18n strings (EN + AM), shared functions |

## How to deploy (GitHub Pages)

1. Copy all 5 files into your GitHub repo root
2. In repo Settings → Pages → set source to `main` branch `/root`
3. Your site live at: `https://israkidan-png.github.io/negarit/`

## Connect Formspree (5 minutes — free)

1. Go to https://formspree.io → Sign up → New Form
2. Copy the Form ID (looks like `xpwzgkrd`)
3. Open `laws-data.js`
4. Find: `const FORMSPREE_ID = "YOUR_FORM_ID";`
5. Replace with: `const FORMSPREE_ID = "xpwzgkrd";` (your actual ID)
6. Push to GitHub — done. Every waitlist signup now arrives in your email.

## Add more laws

Open `laws-data.js` and add to the `LAWS` array:

```js
{
  id:"your-law-id",          // unique slug, used in URLs: law.html?id=your-law-id
  no:"1234/2023",            // proclamation number
  jur:"Federal",             // Federal | Oromia | Amhara | Tigray | SNNPR | etc.
  cat:"Labour",              // Labour | Investment | Tax | Land | Criminal | Commercial | Constitutional
  status:"Active",           // Active | Amended | Repealed
  date:"2023-05-15",         // effective date YYYY-MM-DD
  gazette:"Federal Negarit Gazette, Vol. XX, No. XX — DD Month YYYY",
  akn:"negarit.et/akn/et/act/2023/1234",
  title:"English title here",
  am:"አማርኛ ርዕስ",
  excerpt:"Short English description of the law.",
  excerpt_am:"አጭር የአማርኛ መግለጫ።",
  articles:[
    { num:"Article 1", title:"Short Title", body:"Full article text..." }
  ],
  amendments:[
    { proc:"Proc. No. XXX/YYYY", date:"YYYY-MM-DD", summary:"What changed.", summary_am:"ምን እንደተቀየረ።" }
  ]
}
```

## Partner with Laws.Africa

Contact: info@laws.africa
Subject: "Ethiopia AKN partnership inquiry — Negarit"

They have already built the technical infrastructure for AKN-standard law publishing
across Africa and are actively expanding. A partnership would give Negarit:
- Pre-built ingestion pipeline for Negarit Gazette PDFs
- EU grant eligibility via AfricanLII network
- Instant credibility with international legal institutions

## Language switching

The full EN/AM switch works out of the box. To add more Amharic translations,
open `laws-data.js` and add keys to the `I18N.am` object.
